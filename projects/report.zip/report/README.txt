1)data sets are downloaded from Kaggle on this below link
https://www.kaggle.com/thedownhill/art-images-drawings-painting-sculpture-engraving

notebook used:jupyter notebook
versipon : python3

i have also removed weights files for all models.